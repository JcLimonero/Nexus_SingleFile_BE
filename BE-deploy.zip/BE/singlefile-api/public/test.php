<?php
// Archivo de prueba simple para verificar que el servidor web funciona
echo "¡Hola! El servidor web está funcionando correctamente.\n";
echo "Fecha y hora: " . date('Y-m-d H:i:s') . "\n";
echo "PHP version: " . PHP_VERSION . "\n";
echo "Directorio actual: " . __DIR__ . "\n";
?>
