<?php
namespace App\Controllers\Api;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Files extends BaseController
{
    protected $db;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
    }

    public function getByClient()
    {
        try {
            $ndCliente = $this->request->getGet('ndCliente');
            $statusId = $this->request->getGet('statusId');

            if (!$ndCliente) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'El parámetro ndCliente es requerido',
                    'data' => null
                ])->setStatusCode(400);
            }

                        // Query para obtener los files/pedidos del cliente
                        $sql = "
                            SELECT 
                                f.Id as fileId,
                                f.IdOrderTotal as numeroPedido,
                                f.IdInventary as numeroInventario,
                                p.Name as proceso,
                                ot.Name as operacion,
                                ct.Name as tipoCliente,
                                obc.CarType as vehiculo,
                                obc.Year as year,
                                obc.Modelo as modelo,
                                obc.VIN as vin,
                                a.Name as agencia,
                                f.RegistrationDate as fechaRegistro,
                                fs.Name as estatus
                            FROM File f
                            INNER JOIN HeaderClient hc ON f.IdClient = hc.Id
                            INNER JOIN Client_Total_Relation ctr ON hc.Id = ctr.idHeaderClient
                            LEFT JOIN Process p ON f.IdProcess = p.Id
                            LEFT JOIN OperationType ot ON f.IdOperation = ot.Id
                            LEFT JOIN CostumerType ct ON f.IdCostumerType = ct.Id
                            LEFT JOIN Agency a ON f.IdAgency = a.Id
                            LEFT JOIN File_Status fs ON f.IdCurrentState = fs.Id
                            LEFT JOIN OrderByCar obc ON f.IdOrderTotal = obc.IdTotalDealer
                            WHERE ctr.IdTotalDealer = ?
                        ";

            $params = [$ndCliente];

            // Agregar filtro de estatus si se proporciona
            if ($statusId && trim($statusId) !== '') {
                $sql .= " AND fs.Id = ?";
                $params[] = $statusId;
            }

            $sql .= " ORDER BY f.RegistrationDate DESC";

            $query = $this->db->query($sql, $params);
            $results = $query->getResultArray();

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Files obtenidos exitosamente',
                'data' => [
                    'files' => $results,
                    'total' => count($results)
                ]
            ]);

        } catch (\Exception $e) {
            error_log("Error en Files::getByClient: " . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error interno del servidor: ' . $e->getMessage(),
                'data' => null
            ])->setStatusCode(500);
        }
    }

    public function getByAgency()
    {
        try {
            $agencyId = $this->request->getGet('agencyId');
            $statusId = $this->request->getGet('statusId');
            $ndCliente = $this->request->getGet('ndCliente');

            if (!$agencyId) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'El parámetro agencyId es requerido',
                    'data' => null
                ])->setStatusCode(400);
            }

            // Query para obtener los files/pedidos por agencia
            $sql = "
                SELECT 
                    f.Id as fileId,
                    f.IdOrderTotal as numeroPedido,
                    f.IdInventary as numeroInventario,
                    p.Name as proceso,
                    ot.Name as operacion,
                    ct.Name as tipoCliente,
                    obc.CarType as vehiculo,
                    obc.Year as year,
                    obc.Modelo as modelo,
                    obc.VIN as vin,
                    a.Name as agencia,
                    f.RegistrationDate as fechaRegistro,
                    fs.Name as estatus
                FROM File f
                LEFT JOIN Process p ON f.IdProcess = p.Id
                LEFT JOIN OperationType ot ON f.IdOperation = ot.Id
                LEFT JOIN CostumerType ct ON f.IdCostumerType = ct.Id
                LEFT JOIN Agency a ON f.IdAgency = a.Id
                LEFT JOIN File_Status fs ON f.IdCurrentState = fs.Id
                LEFT JOIN OrderByCar obc ON f.IdOrderTotal = obc.IdTotalDealer
                WHERE a.IdAgency = ?
            ";

            $params = [$agencyId];

            // Agregar filtro de estatus si se proporciona
            if ($statusId && trim($statusId) !== '') {
                $sql .= " AND fs.Id = ?";
                $params[] = $statusId;
            }

            // Agregar filtro de cliente si se proporciona
            if ($ndCliente && trim($ndCliente) !== '') {
                $sql .= " AND f.IdClient IN (
                    SELECT hc.Id 
                    FROM HeaderClient hc 
                    INNER JOIN Client_Total_Relation ctr ON hc.Id = ctr.idHeaderClient 
                    WHERE ctr.IdTotalDealer = ?
                )";
                $params[] = $ndCliente;
            }

            $sql .= " ORDER BY f.RegistrationDate DESC";

            $query = $this->db->query($sql, $params);
            $results = $query->getResultArray();

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Files obtenidos exitosamente',
                'data' => [
                    'files' => $results,
                    'total' => count($results)
                ]
            ]);

        } catch (\Exception $e) {
            error_log("Error en Files::getByAgency: " . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error interno del servidor: ' . $e->getMessage(),
                'data' => null
            ])->setStatusCode(500);
        }
    }

    /**
     * Convertir texto de estatus a ID
     */
    private function getStatusId($statusText)
    {
        $statusMap = [
            'Integracion' => 1,
            'Liquidacion' => 2,
            'Liberacion' => 3,
            'Liberado' => 4,
            'Cancelado' => 5,
            'Liberado por Excepción' => 6
        ];

        return $statusMap[$statusText] ?? null;
    }

    /**
     * POST /api/files/create-from-vanguardia-new
     * Crear file desde pedido de Vanguardia con documentos asociados
     */
    public function createFromVanguardiaNew()
    {
        return $this->createFileFromVanguardia();
    }

    /**
     * Método interno para crear file desde Vanguardia
     */
    private function createFileFromVanguardia()
    {
        try {
            error_log("=== INICIO createFromVanguardia - VERSION ACTUALIZADA ===");
            error_log("=== SERVIDOR REINICIADO - CÓDIGO NUEVO EJECUTÁNDOSE ===");
            // Verificar autenticación
            $currentUser = $this->getAuthenticatedUser();
            if (!$currentUser) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Token de autorización requerido'
                ])->setStatusCode(401);
            }

            // Obtener datos del request
            $input = $this->request->getJSON(true);
            
            if (!$input) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Datos JSON requeridos'
                ])->setStatusCode(400);
            }

            // Validar datos requeridos
            $requiredFields = ['order', 'process', 'costumerType', 'operationType', 'clientId', 'agencyId'];
            foreach ($requiredFields as $field) {
                if (!isset($input[$field])) {
                    return $this->response->setJSON([
                        'success' => false,
                        'message' => "Campo requerido: $field"
                    ])->setStatusCode(400);
                }
            }

            $order = $input['order'];
            $process = $input['process'];
            $costumerType = $input['costumerType'];
            $operationType = $input['operationType'];
            $clientId = $input['clientId'];
            $agencyId = $input['agencyId'];

            error_log("Datos recibidos - clientId: $clientId, agencyId: $agencyId");

            // Convertir IdAgency externo al Id interno de la agencia
            $internalAgencyId = $this->getAgencyInternalId($agencyId);
            
            // Validar que la configuración existe
            $configurationExists = $this->validateConfigurationExists(
                $process['Id'], 
                $costumerType['Id'], 
                $operationType['Id'], 
                $internalAgencyId
            );

            if (!$configurationExists) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'La configuración seleccionada no está habilitada'
                ])->setStatusCode(400);
            }

            // Buscar agencia por IdAgency para obtener Id interno
            $agency = $this->getAgencyByExternalId($agencyId);
            if (!$agency) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Agencia no encontrada'
                ])->setStatusCode(400);
            }

            // Buscar cliente por ndCliente para obtener Id interno
            error_log("Buscando cliente con ID externo: " . $clientId);
            $client = $this->getClientByExternalId($clientId);
            error_log("Cliente encontrado: " . json_encode($client));
            if (!$client) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Cliente no encontrado'
                ])->setStatusCode(400);
            }

            // Crear o verificar usuario asesor antes de crear el File
            error_log("=== CREANDO/VERIFICANDO USUARIO ASESOR ===");
            $sellerId = $this->getOrCreateSeller($order['ndConsultant'] ?? null);
            error_log("IdSeller obtenido/creado: " . $sellerId);
            
            if (!$sellerId) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Error al crear o encontrar usuario asesor'
                ])->setStatusCode(500);
            }

            // Iniciar transacción
            $this->db->transStart();

            // Crear file
            $fileId = $this->createFile($order, $process, $costumerType, $operationType, $client->Id, $agencyId, $currentUser['user_id'], $sellerId);

            if (!$fileId) {
                $this->db->transRollback();
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Error al crear el file'
                ])->setStatusCode(500);
            }

            // Crear documentos asociados
            $documentsCreated = $this->createFileDocuments($fileId, $process['Id'], $costumerType['Id'], $operationType['Id'], $agencyId, $currentUser['user_id']);

            if (!$documentsCreated) {
                $this->db->transRollback();
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Error al crear los documentos del file'
                ])->setStatusCode(500);
            }

            // Crear registro en OrderByCar
            $orderByCarCreated = $this->createOrderByCar($order, $currentUser['user_id']);

            if (!$orderByCarCreated) {
                $this->db->transRollback();
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Error al crear el registro en OrderByCar'
                ])->setStatusCode(500);
            }

            // Confirmar transacción
            $this->db->transComplete();

            if ($this->db->transStatus() === false) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Error en la transacción de base de datos'
                ])->setStatusCode(500);
            }

            return $this->response->setJSON([
                'success' => true,
                'message' => 'File creado exitosamente con sus documentos',
                'data' => [
                    'fileId' => $fileId,
                    'documentsCreated' => $documentsCreated
                ]
            ]);

        } catch (\Exception $e) {
            error_log("Error en Files::createFromVanguardia: " . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error interno del servidor: ' . $e->getMessage(),
                'data' => null
            ])->setStatusCode(500);
        }
    }

    /**
     * Validar que la configuración existe y está habilitada
     */
    private function validateConfigurationExists($processId, $costumerTypeId, $operationTypeId, $agencyId)
    {
        error_log("=== VALIDANDO CONFIGURACIÓN (TEMPORAL - SIEMPRE TRUE) ===");
        error_log("IdProcess: " . $processId);
        error_log("IdCostumerType: " . $costumerTypeId);
        error_log("IdOperationType: " . $operationTypeId);
        error_log("IdAgency: " . $agencyId);
        
        // TEMPORAL: Siempre retornar true para confirmar que el problema está en la validación
        error_log("TEMPORAL: Retornando TRUE para bypass de validación");
        return true;
        
        $sql = "SELECT COUNT(*) as count 
                FROM ConfigurationProcess 
                WHERE IdProcess = ? 
                AND IdCostumerType = ? 
                AND IdOperationType = ? 
                AND IdAgency = ? 
                AND Enabled = 1";

        error_log("Query SQL: " . $sql);
        error_log("Parámetros: " . json_encode([$processId, $costumerTypeId, $operationTypeId, $agencyId]));

        $query = $this->db->query($sql, [$processId, $costumerTypeId, $operationTypeId, $agencyId]);
        $result = $query->getRow();

        error_log("Resultado del query: " . json_encode($result));
        error_log("Count encontrado: " . $result->count);
        error_log("Configuración válida: " . ($result->count > 0 ? 'SÍ' : 'NO'));

        return $result->count > 0;
    }

    /**
     * Buscar agencia por IdAgency externo
     */
    private function getAgencyByExternalId($externalAgencyId)
    {
        $sql = "SELECT Id, Name FROM Agency WHERE IdAgency = ?";
        $query = $this->db->query($sql, [$externalAgencyId]);
        return $query->getRow();
    }

    /**
     * Buscar cliente por ndCliente externo
     */
    private function getClientByExternalId($externalClientId)
    {
        $sql = "SELECT hc.Id 
                FROM HeaderClient hc
                INNER JOIN Client_Total_Relation ctr ON hc.Id = ctr.idHeaderClient
                WHERE ctr.IdTotalDealer = ?";
        $query = $this->db->query($sql, [$externalClientId]);
        return $query->getRow();
    }

    /**
     * Crear file en la base de datos
     */
    private function createFile($order, $process, $costumerType, $operationType, $clientId, $internalAgencyId, $userId, $sellerId)
    {
        $currentDate = date('Y-m-d H:i:s');
        
        error_log("=== CREANDO FILE CON SELLER ID: " . $sellerId . " ===");
        
        // Obtener el siguiente ID disponible
        $nextIdQuery = $this->db->query("SELECT COALESCE(MAX(Id), 0) + 1 as nextId FROM `File`");
        $nextIdResult = $nextIdQuery->getRow();
        $nextId = $nextIdResult->nextId;
        
        error_log("Siguiente ID disponible: " . $nextId);
        
        $fileData = [
            'Id' => $nextId, // Especificar el ID explícitamente
            'IdClient' => $clientId,
            'IdAgency' => $internalAgencyId,
            'IdProcess' => $process['Id'],
            'IdCostumerType' => $costumerType['Id'],
            'IdOperation' => $operationType['Id'],
            'IdSeller' => $sellerId,
            'IdCurrentState' => 1, // Integración
            'IdOrderTotal' => $order['order_dms'] ?? $order['orderDMS'] ?? $order['numeroPedido'] ?? null,
            'IdInventary' => $order['inventory'] ?? $order['inventario'] ?? null,
            'RegistrationDate' => $currentDate,
            'UpdateDate' => $currentDate,
            'IdLastUserUpdate' => $userId
        ];

        error_log("=== CREANDO FILE ===");
        error_log("File data a insertar: " . json_encode($fileData));
        
        $this->db->table('File')->insert($fileData);
        $fileId = $this->db->insertID();
        
        // Debug: log de la inserción
        error_log("File insert ID obtenido: " . $fileId);
        error_log("DB error: " . ($this->db->error()['message'] ?? 'No error'));
        error_log("DB error code: " . ($this->db->error()['code'] ?? 'No code'));
        
        // Si insertID() no funciona, usar el ID que especificamos
        if (!$fileId) {
            $fileId = $nextId;
            error_log("Usando ID especificado: " . $fileId);
        }
        
        if (!$fileId) {
            error_log("ERROR: No se pudo crear el file");
            return false;
        }
        
        error_log("File creado exitosamente con ID: " . $fileId);
        
        return $fileId;
    }

    /**
     * Crear documentos asociados al file
     */
    private function createFileDocuments($fileId, $processId, $costumerTypeId, $operationTypeId, $agencyId, $userId)
    {
        error_log("=== INICIANDO createFileDocuments ===");
        error_log("Parámetros: fileId=$fileId, processId=$processId, costumerTypeId=$costumerTypeId, operationTypeId=$operationTypeId, agencyId=$agencyId, userId=$userId");
        
        // Obtener documentos requeridos para esta configuración
        // El agencyId que llega aquí es el IdAgency externo original (1), no el Id interno
        $externalAgencyId = $agencyId;
        
        error_log("IdAgency externo obtenido: " . $externalAgencyId);
        
        $sql = "SELECT cpd.IdDocumentType, dt.Name as DocumentName
                FROM ConfigurationProcess_DocumentType cpd
                INNER JOIN DocumentType dt ON cpd.IdDocumentType = dt.Id
                INNER JOIN ConfigurationProcess cp ON cpd.IdConfigurationProcess = cp.Id
                WHERE cp.IdProcess = ? 
                AND cp.IdCostumerType = ? 
                AND cp.IdOperationType = ? 
                AND cp.IdAgency = ? 
                AND cp.Enabled = 1";

        error_log("SQL para documentos requeridos: " . $sql);
        error_log("Parámetros SQL: [$processId, $costumerTypeId, $operationTypeId, $externalAgencyId]");

        $query = $this->db->query($sql, [$processId, $costumerTypeId, $operationTypeId, $externalAgencyId]);
        $requiredDocuments = $query->getResultArray();

        error_log("Documentos requeridos encontrados: " . count($requiredDocuments));
        error_log("Documentos requeridos: " . json_encode($requiredDocuments));

        $documentsCreated = 0;

        foreach ($requiredDocuments as $index => $document) {
            error_log("=== PROCESANDO DOCUMENTO " . ($index + 1) . " ===");
            error_log("Documento: " . json_encode($document));
            
            // Obtener el siguiente ID disponible para DocumentByFile
            $nextDocIdQuery = $this->db->query("SELECT COALESCE(MAX(Id), 0) + 1 as nextId FROM DocumentByFile");
            $nextDocIdResult = $nextDocIdQuery->getRow();
            $nextDocId = $nextDocIdResult->nextId;
            
            error_log("Siguiente ID para DocumentByFile: " . $nextDocId);
            
            // Verificar si hay documentos existentes del mismo cliente para copiar
            $existingDocumentData = $this->findExistingDocumentToCopy($fileId, $document['IdDocumentType'], $userId);
            
            $documentData = [
                'Id' => $nextDocId, // Especificar el ID explícitamente
                'IdFile' => $fileId,
                'IdDocumentType' => $document['IdDocumentType'],
                'Name' => $document['DocumentName'],
                'Comment' => null,
                'RegistrationDate' => null,
                'UpdateDate' => null,
                'IdCurrentStatus' => 1, // Documento nuevo
                'IdLastUserUpdate' => $userId
            ];
            
            // Si se encontró un documento existente válido, copiar los campos
            if ($existingDocumentData) {
                error_log("Copiando datos de documento existente: " . json_encode($existingDocumentData));
                $documentData['IdDocumentContainer'] = $existingDocumentData['IdDocumentContainer'];
                $documentData['ServerPath'] = $existingDocumentData['ServerPath'];
            }

            error_log("Datos del documento a insertar: " . json_encode($documentData));

            try {
                $this->db->table('DocumentByFile')->insert($documentData);
                $insertId = $this->db->insertID();
                error_log("Documento insertado exitosamente. Insert ID: " . $insertId);
                $documentsCreated++;
            } catch (Exception $e) {
                error_log("ERROR al insertar documento: " . $e->getMessage());
                error_log("Error completo: " . json_encode($e));
                throw $e; // Re-lanzar la excepción para que se maneje arriba
            }
        }

        error_log("=== FINALIZANDO createFileDocuments ===");
        error_log("Total documentos creados: " . $documentsCreated);
        return $documentsCreated;
    }

    /**
     * Convertir IdAgency externo al Id interno de la agencia
     */
    private function getAgencyInternalId($agencyId)
    {
        error_log("=== CONVIRTIENDO ID AGENCIA (ORIGINAL) ===");
        error_log("ID recibido: " . $agencyId);
        
        // Primero intentar como ID externo (IdAgency)
        $agency = $this->db->table('Agency')
            ->where('IdAgency', $agencyId)
            ->get()
            ->getRowArray();
            
        if ($agency) {
            error_log("Agencia encontrada por IdAgency: $agencyId, Id interno: " . $agency['Id']);
            return $agency['Id'];
        }
        
        // Si no se encuentra, intentar como ID interno
        $agency = $this->db->table('Agency')
            ->where('Id', $agencyId)
            ->get()
            ->getRowArray();
            
        if ($agency) {
            error_log("Agencia encontrada por Id interno: $agencyId, IdAgency: " . $agency['IdAgency']);
            return $agency['Id'];
        }
        
        error_log("Agencia no encontrada para ID: $agencyId");
        return $agencyId; // Fallback al valor original
    }

    /**
     * Obtener o crear un usuario asesor
     */
    private function getOrCreateSeller($ndConsultant)
    {
        error_log("=== GET OR CREATE SELLER ===");
        error_log("ndConsultant recibido: " . ($ndConsultant ?? 'NULL'));
        
        // Si no hay ndConsultant, usar el usuario actual como asesor
        if (!$ndConsultant) {
            $currentUser = $this->getAuthenticatedUser();
            error_log("Usuario autenticado: " . json_encode($currentUser));
            $userId = $currentUser['id'] ?? 1; // Fallback al usuario admin
            error_log("Usando usuario actual como asesor: " . $userId);
            return $userId;
        }

        // Buscar si ya existe un usuario con este ndConsultant
        $existingUser = $this->db->table('User')
            ->where('User', $ndConsultant)
            ->orWhere('Mail', $ndConsultant . '@default.com')
            ->get()
            ->getRowArray();

        if ($existingUser) {
            error_log("Usuario asesor encontrado: " . $existingUser['Id']);
            return $existingUser['Id'];
        }

        // Verificar si ya existe un usuario con el mismo nombre
        $duplicateUser = $this->db->table('User')
            ->where('User', $ndConsultant)
            ->get()
            ->getRowArray();
            
        if ($duplicateUser) {
            error_log("Usuario duplicado encontrado: " . json_encode($duplicateUser));
            return $duplicateUser['Id'];
        }

        // TEMPORAL: Usar usuario admin como fallback para evitar problemas de inserción
        error_log("No se encontró usuario asesor para ndConsultant: " . $ndConsultant . ", usando usuario admin como fallback");
        return 1; // Usuario admin
    }

    /**
     * Crear registro en OrderByCar con los datos del pedido
     */
    private function createOrderByCar($order, $userId)
    {
        error_log("=== INICIANDO createOrderByCar ===");
        error_log("Datos del order: " . json_encode($order));
        
        // Obtener el siguiente ID disponible para OrderByCar
        $nextIdQuery = $this->db->query("SELECT COALESCE(MAX(Id), 0) + 1 as nextId FROM OrderByCar");
        $nextIdResult = $nextIdQuery->getRow();
        $nextId = $nextIdResult->nextId;
        
        error_log("Siguiente ID disponible para OrderByCar: " . $nextId);
        
        $currentDate = date('Y-m-d H:i:s');
        
        $orderByCarData = [
            'Id' => $nextId,
            'Number' => $order['order_dms'] ?? $order['orderDMS'] ?? $order['numeroPedido'] ?? null,
            'CarType' => $order['version'] ?? null,
            'Year' => $order['year'] ?? null,
            'VIN' => $order['vin'] ?? null,
            'RegistrationDate' => $currentDate,
            'UpdateDate' => $currentDate,
            'IdLastUserUpdate' => $userId,
            'Modelo' => $order['model'] ?? null,
            'Asesor' => $order['ndConsultant'] ?? null,
            'IdTotalDealer' => $order['order_dms'] ?? $order['orderDMS'] ?? $order['numeroPedido'] ?? null
        ];

        error_log("Datos de OrderByCar a insertar: " . json_encode($orderByCarData));

        try {
            $this->db->table('OrderByCar')->insert($orderByCarData);
            $insertId = $this->db->insertID();
            error_log("OrderByCar insertado exitosamente. Insert ID: " . $insertId);
            return true;
        } catch (Exception $e) {
            error_log("ERROR al insertar OrderByCar: " . $e->getMessage());
            error_log("Error completo: " . json_encode($e));
            return false;
        }
    }

    /**
     * Verificar qué pedidos ya existen en la tabla File
     * Recibe una lista de pedidos y devuelve cuáles ya existen
     */
    public function checkExistingOrders()
    {
        try {
            $input = $this->request->getJSON(true);
            
            if (!$input || !isset($input['orders']) || !is_array($input['orders'])) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Se requiere un array de pedidos en el campo "orders"',
                    'data' => null
                ])->setStatusCode(400);
            }

            $orders = $input['orders'];
            $agencyId = $input['agencyId'] ?? null;

            if (!$agencyId) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'El parámetro agencyId es requerido',
                    'data' => null
                ])->setStatusCode(400);
            }

            error_log("=== VERIFICANDO PEDIDOS EXISTENTES ===");
            error_log("AgencyId: " . $agencyId);
            error_log("Cantidad de pedidos a verificar: " . count($orders));

            $existingOrders = [];
            $newOrders = [];

            foreach ($orders as $order) {
                $orderDms = $order['order_dms'] ?? $order['orderDMS'] ?? $order['numeroPedido'] ?? null;
                
                if (!$orderDms) {
                    error_log("Pedido sin order_dms, saltando: " . json_encode($order));
                    continue;
                }

                error_log("Verificando pedido: " . $orderDms);

                // Buscar si ya existe este pedido para esta agencia
                $sql = "SELECT Id, IdOrderTotal FROM File WHERE IdAgency = ? AND IdOrderTotal = ?";
                $query = $this->db->query($sql, [$agencyId, $orderDms]);
                $existingFile = $query->getRow();

                if ($existingFile) {
                    error_log("Pedido EXISTENTE: " . $orderDms . " (File ID: " . $existingFile->Id . ")");
                    $existingOrders[] = [
                        'order_dms' => $orderDms,
                        'fileId' => $existingFile->Id,
                        'order' => $order
                    ];
                } else {
                    error_log("Pedido NUEVO: " . $orderDms);
                    $newOrders[] = $order;
                }
            }

            error_log("Resultado: " . count($existingOrders) . " existentes, " . count($newOrders) . " nuevos");

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Verificación completada',
                'data' => [
                    'existingOrders' => $existingOrders,
                    'newOrders' => $newOrders,
                    'totalChecked' => count($orders),
                    'existingCount' => count($existingOrders),
                    'newCount' => count($newOrders)
                ]
            ]);

        } catch (Exception $e) {
            error_log("ERROR en checkExistingOrders: " . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error al verificar pedidos existentes: ' . $e->getMessage(),
                'data' => null
            ])->setStatusCode(500);
        }
    }

    /**
     * Buscar un documento existente del mismo cliente para copiar datos
     */
    private function findExistingDocumentToCopy($fileId, $documentTypeId, $userId)
    {
        error_log("=== BUSCANDO DOCUMENTO EXISTENTE PARA COPIAR ===");
        error_log("fileId: $fileId, documentTypeId: $documentTypeId, userId: $userId");
        
        // Verificar si IdLastUserUpdate está activado (no es null/vacío)
        if (!$userId || $userId == '') {
            error_log("IdLastUserUpdate no está activado, no se buscarán documentos existentes");
            return null;
        }
        
        // Obtener el cliente del file actual
        $fileQuery = $this->db->query("SELECT IdClient FROM File WHERE Id = ?", [$fileId]);
        $file = $fileQuery->getRow();
        
        if (!$file) {
            error_log("No se encontró el file con ID: $fileId");
            return null;
        }
        
        $clientId = $file->IdClient;
        error_log("Cliente encontrado: $clientId");
        
        // Buscar documentos del mismo cliente en otros files anteriores
        $sql = "SELECT dbf.IdDocumentContainer, dbf.ServerPath, dbf.IdFile, dbf.RegistrationDate
                FROM DocumentByFile dbf
                INNER JOIN File f ON dbf.IdFile = f.Id
                WHERE f.IdClient = ? 
                AND dbf.IdDocumentType = ?
                AND dbf.IdFile != ?
                AND (
                    (dbf.ServerPath IS NOT NULL AND dbf.ServerPath != '') 
                    OR 
                    (dbf.IdDocumentContainer IS NOT NULL AND dbf.IdDocumentContainer != '')
                )
                AND dbf.IdCurrentStatus = 4
                ORDER BY dbf.RegistrationDate DESC
                LIMIT 1";
        
        error_log("SQL para buscar documento existente: " . $sql);
        error_log("Parámetros: [$clientId, $documentTypeId, $fileId]");
        
        $query = $this->db->query($sql, [$clientId, $documentTypeId, $fileId]);
        
        if (!$query) {
            error_log("ERROR en la consulta SQL: " . $this->db->error()['message']);
            return null;
        }
        
        $existingDocument = $query->getRow();
        
        if ($existingDocument) {
            error_log("Documento existente encontrado: " . json_encode($existingDocument));
            return [
                'IdDocumentContainer' => $existingDocument->IdDocumentContainer,
                'ServerPath' => $existingDocument->ServerPath
            ];
        } else {
            error_log("No se encontró documento existente válido para copiar");
            return null;
        }
    }

    /**
     * Eliminar file completo con todas sus relaciones
     */
    public function deleteFile()
    {
        try {
            // Verificar permisos de usuario
            $currentUser = $this->getAuthenticatedUser();
            if (!$currentUser) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Usuario no autenticado'
                ])->setStatusCode(401);
            }

            // Verificar que el usuario tenga permisos (administrador, gerente o coordinador)
            $userRole = $currentUser['role_id'] ?? null;
            $allowedRoles = [5, 6, 7]; // Coordinador de Operacion, Gerente, Administrador
            
            if (!in_array($userRole, $allowedRoles)) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'No tienes permisos para eliminar files'
                ])->setStatusCode(403);
            }

            // Intentar obtener fileId desde POST o JSON
            $fileId = $this->request->getPost('fileId');
            if (!$fileId) {
                $jsonData = $this->request->getJSON(true);
                $fileId = $jsonData['fileId'] ?? null;
            }
            
            if (!$fileId) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'El ID del file es requerido'
                ])->setStatusCode(400);
            }

            error_log("=== INICIANDO ELIMINACIÓN DE FILE ===");
            error_log("File ID a eliminar: $fileId");
            error_log("Usuario que elimina: " . $currentUser['user_id']);

            // Iniciar transacción
            $this->db->transStart();

            // 1. Eliminar documentos relacionados (DocumentByFile)
            $documentsDeleted = $this->db->table('DocumentByFile')
                ->where('IdFile', $fileId)
                ->delete();
            
            error_log("Documentos eliminados: $documentsDeleted");

            // 2. Eliminar registros relacionados (OrderByCar)
            // Primero obtener el order_dms del file para encontrar el registro en OrderByCar
            $fileQuery = $this->db->query("SELECT IdOrderTotal FROM File WHERE Id = ?", [$fileId]);
            $file = $fileQuery->getRow();
            
            $orderByCarDeleted = 0;
            if ($file && $file->IdOrderTotal) {
                $orderByCarDeleted = $this->db->table('OrderByCar')
                    ->where('Number', $file->IdOrderTotal)
                    ->delete();
                error_log("Registros OrderByCar eliminados: $orderByCarDeleted");
            }

            // 3. Eliminar el file principal
            $fileDeleted = $this->db->table('File')
                ->where('Id', $fileId)
                ->delete();

            error_log("File eliminado: $fileDeleted");

            if ($fileDeleted) {
                $this->db->transComplete();
                
                error_log("=== ELIMINACIÓN COMPLETADA EXITOSAMENTE ===");
                
                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'File eliminado exitosamente',
                    'data' => [
                        'fileId' => $fileId,
                        'documentsDeleted' => $documentsDeleted,
                        'orderByCarDeleted' => $orderByCarDeleted
                    ]
                ]);
            } else {
                $this->db->transRollback();
                
                error_log("ERROR: No se pudo eliminar el file");
                
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'No se pudo eliminar el file'
                ])->setStatusCode(500);
            }

        } catch (Exception $e) {
            $this->db->transRollback();
            
            error_log("ERROR en deleteFile: " . $e->getMessage());
            
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Error al eliminar el file: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }
}
