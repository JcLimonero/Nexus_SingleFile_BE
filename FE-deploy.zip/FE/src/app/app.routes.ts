import { LayoutComponent } from './layouts/layout/layout.component';
import { VexRoutes } from '@vex/interfaces/vex-route.interface';
import { LoginGuard } from './core/guards/login.guard';
import { AuthGuard } from './core/guards/auth.guard';

export const appRoutes: VexRoutes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./pages/pages/auth/login/login.component').then(
        (m) => m.LoginComponent
      ),
    canActivate: [LoginGuard]
  },
  {
    path: 'register',
    loadComponent: () =>
      import('./pages/pages/auth/register/register.component').then(
        (m) => m.RegisterComponent
      )
  },
  {
    path: 'forgot-password',
    loadComponent: () =>
      import(
        './pages/pages/auth/forgot-password/forgot-password.component'
      ).then((m) => m.ForgotPasswordComponent)
  },
  {
    path: 'coming-soon',
    loadComponent: () =>
      import('./pages/pages/coming-soon/coming-soon.component').then(
        (m) => m.ComingSoonComponent
      )
  },
  {
    path: '',
    component: LayoutComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'dashboards/analytics',
        redirectTo: '/',
        pathMatch: 'full'
      },
      {
        path: 'dashboards/admin-analytics',
        loadComponent: () =>
          import(
            './pages/dashboards/dashboard-admin-analytics/dashboard-admin-analytics.component'
          ).then((m) => m.DashboardAdminAnalyticsComponent)
      },
      {
        path: '',
        loadComponent: () =>
          import(
            './pages/dashboards/dashboard-analytics/dashboard-analytics.component'
          ).then((m) => m.DashboardAnalyticsComponent)
      },
      {
        path: 'apps',
        children: [
          {
            path: 'chat',
            loadChildren: () => import('./pages/apps/chat/chat.routes')
          },
          {
            path: 'mail',
            loadChildren: () => import('./pages/apps/mail/mail.routes'),
            data: {
              toolbarShadowEnabled: true,
              scrollDisabled: true
            }
          },
          {
            path: 'social',
            loadChildren: () => import('./pages/apps/social/social.routes')
          },
          {
            path: 'contacts',
            loadChildren: () => import('./pages/apps/contacts/contacts.routes')
          },
          {
            path: 'calendar',
            loadComponent: () =>
              import('./pages/apps/calendar/calendar.component').then(
                (m) => m.CalendarComponent
              ),
            data: {
              toolbarShadowEnabled: true
            }
          },
          {
            path: 'aio-table',
            loadComponent: () =>
              import('./pages/apps/aio-table/aio-table.component').then(
                (m) => m.AioTableComponent
              ),
            data: {
              toolbarShadowEnabled: false
            }
          },
          {
            path: 'help-center',
            loadChildren: () =>
              import('./pages/apps/help-center/help-center.routes')
          },
          {
            path: 'scrumboard',
            loadChildren: () =>
              import('./pages/apps/scrumboard/scrumboard.routes')
          },
          {
            path: 'editor',
            loadComponent: () =>
              import('./pages/apps/editor/editor.component').then(
                (m) => m.EditorComponent
              ),
            data: {
              scrollDisabled: true
            }
          }
        ]
      },
      {
        path: 'pages',
        children: [
          {
            path: 'pricing',
            loadComponent: () =>
              import('./pages/pages/pricing/pricing.component').then(
                (m) => m.PricingComponent
              )
          },
          {
            path: 'faq',
            loadComponent: () =>
              import('./pages/pages/faq/faq.component').then(
                (m) => m.FaqComponent
              )
          },
          {
            path: 'guides',
            loadComponent: () =>
              import('./pages/pages/guides/guides.component').then(
                (m) => m.GuidesComponent
              )
          },
          {
            path: 'invoice',
            loadComponent: () =>
              import('./pages/pages/invoice/invoice.component').then(
                (m) => m.InvoiceComponent
              )
          },
          {
            path: 'error-404',
            loadComponent: () =>
              import('./pages/pages/errors/error-404/error-404.component').then(
                (m) => m.Error404Component
              )
          },
          {
            path: 'error-500',
            loadComponent: () =>
              import('./pages/pages/errors/error-500/error-500.component').then(
                (m) => m.Error500Component
              )
          }
        ]
      },
      {
        path: 'ui',
        children: [
          {
            path: 'components',
            loadChildren: () =>
              import('./pages/ui/components/components.routes')
          },
          {
            path: 'forms/form-elements',
            loadComponent: () =>
              import(
                './pages/ui/forms/form-elements/form-elements.component'
              ).then((m) => m.FormElementsComponent)
          },
          {
            path: 'forms/form-wizard',
            loadComponent: () =>
              import('./pages/ui/forms/form-wizard/form-wizard.component').then(
                (m) => m.FormWizardComponent
              )
          },
          {
            path: 'icons',
            loadChildren: () => import('./pages/ui/icons/icons.routes')
          },
          {
            path: 'page-layouts',
            loadChildren: () =>
              import('./pages/ui/page-layouts/page-layouts.routes')
          }
        ]
      },
      {
        path: 'documentation',
        loadChildren: () => import('./pages/documentation/documentation.routes')
      },
      {
        path: 'configuracion',
        children: [
          {
            path: 'general',
            loadComponent: () =>
              import('./pages/configuracion/configuracion-general/configuracion-general.component').then(
                (m) => m.ConfiguracionGeneralComponent
              )
          },
          {
            path: 'documentos-requeridos',
            loadComponent: () =>
              import('./pages/configuracion/documentos-requeridos/documentos-requeridos.component').then(
                (m) => m.DocumentosRequeridosComponent
              )
          },
          {
            path: 'usuarios',
            loadComponent: () =>
              import('./pages/configuracion/usuarios/usuarios.component').then(
                (m) => m.UsuariosComponent
              )
          },
          {
            path: 'logs-activity',
            loadComponent: () =>
              import('./pages/configuracion/logs-activity/logs-activity.component').then(
                (m) => m.LogsActivityComponent
              )
          },
          {
            path: 'motivos-rechazo',
            loadComponent: () =>
              import('./pages/configuracion/motivos-rechazo/motivos-rechazo.component').then(
                (m) => m.MotivosRechazoComponent
              )
          },
          {
            path: 'motivos-extraordinarios',
            loadComponent: () =>
              import('./pages/configuracion/motivos-extraordinarios/motivos-extraordinarios.component').then(
                (m) => m.MotivosExtraordinariosComponent
              )
          }
        ]
      },
              {
          path: 'configuracion/catalogos',
          children: [
            {
              path: 'agencias',
              loadComponent: () =>
                import('./pages/configuracion/catalogos/agencias/agencias.component').then(
                  (m) => m.AgenciasComponent
                )
            },
            {
              path: 'procesos',
              loadComponent: () =>
                import('./pages/configuracion/catalogos/procesos/procesos.component').then(
                  (m) => m.ProcesosComponent
                )
            },
            {
              path: 'tipos-operacion',
              loadComponent: () =>
                import('./pages/configuracion/catalogos/tipos-operacion/tipos-operacion.component').then(
                  (m) => m.TiposOperacionComponent
                )
            },
            {
              path: 'tipos-cliente',
              loadComponent: () =>
                import('./pages/configuracion/tipos-cliente/tipos-cliente.component').then(
                  (m) => m.TiposClienteComponent
                )
            },
            {
              path: 'tipos-documento',
              loadComponent: () =>
                import('./pages/configuracion/tipos-documento/tipos-documento.component').then(
                  (m) => m.TiposDocumentoComponent
                )
            }
                  ]
      },
      {
        path: 'procesos',
        children: [
          {
            path: 'integracion',
            loadComponent: () =>
              import('./pages/procesos/integracion/integracion.component').then(
                (m) => m.IntegracionComponent
              )
          },
          {
            path: 'gestion',
            loadComponent: () =>
              import('./pages/procesos/gestion/gestion.component').then(
                (m) => m.GestionComponent
              )
          }
        ]
      },
      {
        path: 'mesa-control',
        children: [
          {
            path: 'dashboard',
            loadComponent: () =>
              import('./pages/mesa-control/dashboard/dashboard.component').then(
                (m) => m.DashboardComponent
              )
          },
          {
            path: 'monitoreo',
            loadComponent: () =>
              import('./pages/mesa-control/monitoreo/monitoreo.component').then(
                (m) => m.MonitoreoComponent
              )
          },
          {
            path: 'reportes',
            loadComponent: () =>
              import('./pages/mesa-control/reportes/reportes.component').then(
                (m) => m.ReportesComponent
              )
          },
          {
            path: 'validacion',
            loadComponent: () =>
              import('./pages/mesa-control/validacion/validacion.component').then(
                (m) => m.ValidacionComponent
              )
          }
        ]
      },
      {
        path: '**',
        loadComponent: () =>
          import('./pages/pages/errors/error-404/error-404.component').then(
            (m) => m.Error404Component
          )
      }
    ]
  }
];
