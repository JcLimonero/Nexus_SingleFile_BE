import { Component } from '@angular/core';

@Component({
  selector: 'vex-monitoreo',
  standalone: true,
  imports: [],
  templateUrl: './monitoreo.component.html',
  styleUrl: './monitoreo.component.scss'
})
export class MonitoreoComponent {

}
