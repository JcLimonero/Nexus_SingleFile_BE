export const environment = {
  production: true,
  apiBaseUrl: 'http://localhost:401'
};
