<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class File extends BaseController
{
    public function index()
    {
        //
    }
}
