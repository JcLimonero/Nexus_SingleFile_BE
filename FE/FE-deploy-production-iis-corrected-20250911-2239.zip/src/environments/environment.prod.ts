export const environment = {
  production: true,
  apiBaseUrl: 'http://192.168.190.140:401', // Cambiar por la URL real de producción
  backblaze: {
    apiUrl: 'https://apisvanguardia.com:400',
    providerToken: 'b26e88c4-ddbe-4adb-a214-4667f454824a'
  }
};
